<?php $__env->startSection('content'); ?>
<div class="header bg-gradient-warning pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-lg-6">
            <div class="card">
            <div class="card-header">
                Ubah Akun
            </div>
                <div class="card-body">
                    <form action="/akun_user_update" method="POST">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($r->id); ?>">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e($r->nama); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" name="username" id="username" class="form-control" value="<?php echo e($r->username); ?>" >
                        </div>
                        <label for="level">Level</label>
                        <select name="level" id="level" class="form-control">
                            <?php if($r->level == 'admin'): ?>
                            <option value="admin" selected>Admin</option>
                            <?php else: ?>
                            <option value="admin">Admin</option>
                            <?php endif; ?>
                            
                            <?php if($r->level == 'waiter'): ?>
                            <option value="waiter" selected>Waiter</option>
                            <?php else: ?>
                            <option value="waiter">Waiter</option>
                            <?php endif; ?>
                            
                            <?php if($r->level == 'owner'): ?>
                            <option value="owner" selected>Owner</option>
                            <?php else: ?>
                            <option value="owner">Owner</option>
                            <?php endif; ?>
                            
                            <?php if($r->level == 'kasir'): ?>
                            <option value="kasir" selected>Kasir</option>
                            <?php else: ?>
                            <option value="kasir">Kasir</option>
                            <?php endif; ?>
                            
                            <?php if($r->level == 'pelanggan'): ?>
                            <option value="pelanggan" selected>Pelanggan</option>
                            <?php else: ?>
                            <option value="pelanggan">Pelanggan</option>
                            <?php endif; ?>
                        </select>
                        <br>
                        <button type="submit" class="btn btn-primary ">Ubah</button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>
                </div>
            </div>
            </div>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\sp1\resources\views/pengguna/edit.blade.php ENDPATH**/ ?>