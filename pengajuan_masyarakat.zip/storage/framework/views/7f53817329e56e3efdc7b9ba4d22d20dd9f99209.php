<?php $__env->startSection('content'); ?> 
<style>
</style>
<title>Home | Layanan Pengaduan Masyarat</title>
<!-- Jumbotron -->
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <?php if($aplikasi==''): ?>
      <h1 class="display-4">Layanan Pengaduan Masyarakat</h1>
      <a href="/lapor" class="btn btn-primary lapor">Sampaikan Pengaduan Disini</a>
    <?php else: ?>
      <h1 class="display-4"><?php echo e($aplikasi->deskripsi_aplikasi); ?></h1>
      <a href="/lapor" class="btn btn-primary lapor">Sampaikan Pengaduan Disini</a>
    <?php endif; ?>
  </div>
</div>
<!-- akhir Jumbotron -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\colongan\pengajuan_masyarakat\resources\views/masyarakat/index.blade.php ENDPATH**/ ?>