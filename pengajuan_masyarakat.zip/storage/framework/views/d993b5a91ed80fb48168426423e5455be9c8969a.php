<?php $__env->startSection('content'); ?>
<title>Login | Aplikasi Pengaduan Masyarakat</title>
<body>
<div class="container">
	<div class="row mt-5">
		<div class="col-md-4"></div>
            <div class="col-md-4 bg-light shadow-2 rounded">
                <div class="card-body ">
					<h1 class="card-title text-center"><br><h2><center><font class="text-primary"><b>Aspirasi Ku</b></font></h2></h1>
					<p class="text-center" style="font-style: Helvetica">Layanan Pengaduan Masyarakat</p> </center>    <hr>
                    <form method="POST" action="<?php echo e(route('login')); ?>">		
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label for="username">Username</label>
						<input id="username" autofocus type="text" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required>
					</div>
					<div class="form-group">
						<label for="myInput">Password</label>					
						<div class="input-group input-group-xs">
							<input id="myInput" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required data-toggle="password">
							
							<div class="input-group-append">
								<i onclick="myFunction()" class="fa fa-eye btn btn-primary" id="mata"></i>
							</div>
						</div>
					</div>
					<button type="submit" class="btn btn-primary w-100 mb-2">
							<?php echo e(__('Login')); ?>

					</button>	
					<?php if( Session::get('alert') !=""): ?>
						<div class='alert alert-success'><center><b><?php echo e(Session::get('alert')); ?></b></center></div>
					<?php endif; ?>
					<?php if(session('status')): ?>
						<div class="alert alert-success" role="alert">
						<center><b><?php echo e(session('status')); ?></b></center>
						</div>
					<?php endif; ?>
						<br>
						<br>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

</body>

<script>
$('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})


$("#password").password('toggle');

function myFunction() {
  var x = document.getElementById("myInput");
  var z = document.getElementById("mata");
  if (x.type=== "password") {
    x.type = "text";
    $("#mata").toggleClass("fa-eye-slash");
  } else if (x.type === "text") {
    x.type = "password";
    $("#mata").removeClass("fa-eye-slash");
  }
  
}



</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\pengajuan_masyarakat\resources\views/auth/login.blade.php ENDPATH**/ ?>