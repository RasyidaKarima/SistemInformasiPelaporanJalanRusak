<?php $__env->startSection('content'); ?>

<title>
  Tambah Kategori | Aplikasi Kasir Restoran
</title>
<div class="header bg-gradient-warning pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-lg-6">
            <div class="card">
            <div class="card-header">
                Tambah Kategori
            </div>
                <div class="card-body">
                    <form action="kategori_tambah_post" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="nama_kategori">Nama Kategori</label>
                            <input type="text" name="nama_kategori" id="nama_kategori" class="form-control" value="<?php echo e(old('nama_kategori')); ?>">
                        </div>
                        <br>
                        <button type="submit" class="btn btn-primary ">Tambah</button>
                    </form>
                </div>
            </div>
            </div>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\sp1\resources\views/kategori/tambah.blade.php ENDPATH**/ ?>