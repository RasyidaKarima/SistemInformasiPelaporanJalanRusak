<?php $__env->startSection('content'); ?>
<title>
    Detail Data Admin  | BKP Online
 </title>
<!-- Header -->
<div class="header pb-6 d-flex align-items-center" style="min-height: 300px; background-image: url(../../assets/img/brand/1.jpg); background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-primary opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid">
        <div class="col-auto">
        </div>
    </div>
</div>
    
<br>
<br>
<div class="container-fluid mt--7">

  <div class="row">
  <div class="col-xl-8 order-xl-2 offset-2">
    <div class="card shadow">
                    <div class="card-body">
                    <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="/admin_update">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" class="form-control" id="id" name="id" value="<?php echo e($p->id); ?>">

                    <div class="form-group">
                      <div class="form-group">
                        <label for="nama" class="col-sm-4 control-label">Nama</label>

                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($p->nama); ?>">
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="form-group">
                        <label for="username" class="col-sm-4 control-label">Username</label>

                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo e($p->username); ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-group">
                        <label for="email" class="col-sm-4 control-label">Email</label>

                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="email" name="email" value="<?php echo e($p->email); ?>" readonly>
                        </div>
                      </div>
                    </div>


                      <div class="form-group">
                        <div class="form-group">
                          <div class="col-sm-10">
                          <button class="btn btn-primary btn-md">Ubah</button>
                          </div>
                      </div>

                      </form>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    </div>
  </div>
</div>

</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\bkp\resources\views/pengguna/detail_admin.blade.php ENDPATH**/ ?>