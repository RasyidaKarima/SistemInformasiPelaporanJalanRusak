<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Aspirasi Ku | Layanan Aspirasi Masyarakat</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->	
	<link rel="icon" type="image/png" href="<?php echo e(url('assets/login/images/icons/favicon.ico')); ?>"/>
  <link href="<?php echo e(url('assets/fitur/assets/img/apple-touch-icon.png" rel="apple')); ?>-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<link href="<?php echo e(url('assets/arsitek/main.css')); ?>" rel="stylesheet">
  <!-- Vendor CSS Files -->
  <link href="<?php echo e(url('assets/fitur/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(url('assets/fitur/assets/vendor/icofont/icofont.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(url('assets/fitur/assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(url('assets/fitur/assets/vendor/line-awesome/css/line-awesome.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(url('assets/fitur/assets/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(url('assets/fitur/assets/css/style.css')); ?>" rel="stylesheet">
<link href="/<?php echo e(url('assets/fontawesome/css/all.css')); ?>" rel="stylesheet"> <!--load all styles -->
<link href="<?php echo e(url('assets/fontawesome/css/fontawesome.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('assets/fontawesome/css/brands.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(url('assets/arsitek/Pe-icon-7-stroke.css')); ?>">
<link href="<?php echo e(url('assets/fontawesome/css/solid.css')); ?>" rel="stylesheet">


</head>

<body>

  <!-- ======= Mobile Menu ======= -->
  <div class="site-mobile-menu site-navbar-target">
    <div class="site-mobile-menu-header">
      <div class="site-mobile-menu-close mt-3">
        <span class="icofont-close js-menu-toggle"></span>
      </div>
    </div>
    <div class="site-mobile-menu-body"></div>
  </div>

  <!-- ======= Header ======= -->
  <header class="site-navbar js-sticky-header site-navbar-target" role="banner">

    <div class="container">
      <div class="row align-items-center">

        <div class="col-6 col-lg-2">
          <h1 class="mb-0 site-logo"><a href="/index" class="mb-0">Aspirasi Ku</a></h1>
        </div>

        <div class="col-12 col-md-10 d-none d-lg-block">
          <nav class="site-navigation position-relative text-right" role="navigation">

            <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
              <li class="active"><a href="/index" class="nav-link">Home</a></li>

              <li class="has-children">
                <a href="#" class="nav-link">Lainnya</a>
                <ul class="dropdown">
                <li><a class="dropdown-item"><i class="fas fa-sign-out-alt"></i> &nbsp;Profile</a></li>
                <li><a class="dropdown-item" href="/lapor"><i class="fas fa-sign-out-alt"></i> &nbsp;Lapor</a></li>
                <li><a class="dropdown-item" href="/data_laporan"><i class="fas fa-sign-out-alt"></i> &nbsp;Data Laporan</a></li>
                  <li>

                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                      <?php echo csrf_field(); ?>
                  </form>                 
                  <a class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                          <i class="fas fa-sign-out-alt"></i> &nbsp;<?php echo e(__('Logout')); ?>

                          </a>

                  </li>
                </ul>
              </li>
            </ul>
          </nav>
        </div>
        

        <div class="col-6 d-inline-block d-lg-none ml-md-0 py-3" style="position: relative; top: 3px;">

          <a href="#" class="burger site-menu-toggle js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
            <span></span>
          </a>
        </div>

      </div>
    </div>

  </header>
  
  <?php echo $__env->yieldContent('content'); ?>
  <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(url('assets/fitur/assets/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/fitur/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/fitur/assets/vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/fitur/assets/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(url('assets/fitur/assets/vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(url('assets/fitur/assets/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/fitur/assets/vendor/jquery-sticky/jquery.sticky.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(url('assets/fitur/assets/js/main.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(url('assets/arsitek/scripts/main.js')); ?>"></script></body>

</body>

</html><?php /**PATH D:\Xampp\XAMPP\htdocs\sp1\resources\views/layouts/layout.blade.php ENDPATH**/ ?>