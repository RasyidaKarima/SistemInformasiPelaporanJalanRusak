<?php $__env->startSection('content'); ?>
<title>Pendaftaran | Layanan Pengaduan Masyarakat </title>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-4"></div>
            <div class="col-md-4 bg-light shadow-2 rounded">
                <div class="card-body ">
                <?php if( Session::get('alert') !=""): ?>
                    <div class='alert alert-success'><center><b><?php echo e(Session::get('alert')); ?></b></center></div>       
                <?php endif; ?>
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <center><b><?php echo e(session('status')); ?></b></center>
                    </div>
                <?php endif; ?>
                <form method="POST" action="/daftar_post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nik">NIK : <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                        <input type="number" name="nik" class="form-control" onKeyPress="if(this.value.length==16) return false;" value="<?php echo e(old('nik')); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="nama">Nama : <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                        <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama')); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="username">Username : <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                        <input type="text" name="username" class="form-control" value="<?php echo e(old('username')); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email : <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                        <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="telp">No. Telp : <?php $__errorArgs = ['telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                        <input type="number" name="telp" class="form-control" value="<?php echo e(old('telp')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="myInput">Password :  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($errors->first('password')); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                    <div class="input-group input-group-xs">
                        <input id="myInput" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required data-toggle="password">                        <div class="input-group-append">
                            <i onclick="myFunction()" class="fa fa-eye btn btn-primary" id="mata"></i>
                        </div>
                    </div>
                    
                    </div>
                    
                    <div class="form-group">
                        <label for="myInput2">Password Confirm :</label>
                    <div class="input-group input-group-xs">
                        <input id="myInput2" type="password" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" name="password_confirmation" required data-toggle="password_confirmation">      
                        <div class="input-group-append">
                            <i onclick="myFunction2()" class="fa fa-eye btn btn-primary" id="mata2"></i>
                        </div>
                    </div>
                    
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100 mb-2">
                        Register
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

</body>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">

</script>

<script  src="/path/to/bootstrap-show-password.js"></script>

<script>
$('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})


$("#password").password('toggle');

function myFunction() {
  var x = document.getElementById("myInput");
  var z = document.getElementById("mata");
  if (x.type=== "password") {
    x.type = "text";
    $("#mata").toggleClass("fa-eye-slash");
  } else if (x.type === "text") {
    x.type = "password";
    $("#mata").removeClass("fa-eye-slash");
  }
  
}


function myFunction2() {
  var x = document.getElementById("myInput2");
  var z = document.getElementById("mata2");
  if (x.type=== "password") {
    x.type = "text";
    $("#mata2").toggleClass("fa-eye-slash");
  } else if (x.type === "text") {
    x.type = "password";
    $("#mata2").removeClass("fa-eye-slash");
  }
  
}



</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\pengajuan_masyarakat\resources\views/daftar/daftar.blade.php ENDPATH**/ ?>