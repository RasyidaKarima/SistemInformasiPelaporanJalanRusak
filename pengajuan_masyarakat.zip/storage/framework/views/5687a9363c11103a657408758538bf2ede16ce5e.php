<!doctype html>
<html lang="en">
<style>
.metismenu-icon{
    color: black !important;
}
</style>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Dashboard | Layanan Aspirasi Masyarakat</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
    <!--
    =========================================================
    * ArchitectUI HTML Theme Dashboard - v1.0.0
    =========================================================
    * Product Page: https://dashboardpack.com
    * Copyright 2019 DashboardPack (https://dashboardpack.com)
    * Licensed under MIT (https://github.com/DashboardPack/architectui-html-theme-free/blob/master/LICENSE)
    =========================================================
    * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
    -->
    </head>
<link href="<?php echo e(url('assets/arsitek/main.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(url('assets/arsitek/Pe-icon-7-stroke.css')); ?>">
<link href="/<?php echo e(url('assets/fontawesome/css/all.css')); ?>" rel="stylesheet"> <!--load all styles -->
<link href="<?php echo e(url('assets/fontawesome/css/fontawesome.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('assets/fontawesome/css/brands.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('assets/fontawesome/css/solid.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"><h5>Aspirasi Ku</h5></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    <div class="app-header__content">
                <div class="app-header-right">
                    <div class="header-btn-lg pr-0">
                        <div class="widget-content p-0">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left">
                                    <div class="btn-group">
                                        <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="p-0 btn">
                                            <img width="42" class="rounded-circle" src="<?php echo e(url('assets/arsitek/images/avatars/1.jpg')); ?>" alt="">
                                            <i class="fa fa-angle-down ml-2 opacity-8"></i>
                                        </a>
                                        <div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu dropdown-menu-right">
                                            <button type="button" tabindex="0" class="dropdown-item"><i class="fas fa-users"></i> &nbsp; User Account</button>
                                            <button type="button" tabindex="0" class="dropdown-item"><i class="fas fa-cogs"></i> &nbsp; Settings</button>
                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                            <i class="fas fa-sign-out-alt"></i> &nbsp;<?php echo e(__('Logout')); ?>

                                            </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content-left  ml-3 header-user-info">
                                    <div class="widget-heading">
                                        Alina Mclourd
                                    </div>
                                    <div class="widget-subheading">
                                        VP People Manager
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>        
                </div>
            </div>
        </div>        
        
        <div class="app-main">
                <div class="app-sidebar sidebar-shadow">
                    <div class="app-header__logo">
                        <div class="logo-src"></div>
                        <div class="header__pane ml-auto">
                            <div>
                                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="app-header__mobile-menu">
                        <div>
                            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="app-header__menu">
                        <span>
                            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                <span class="btn-icon-wrapper">
                                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                                </span>
                            </button>
                        </span>
                    </div>    <div class="scrollbar-sidebar">
                        <div class="app-sidebar__inner">
                            <ul class="vertical-nav-menu">
                                <li class="app-sidebar__heading">Dashboards</li>
                                <li>
                                <?php if(Auth::user()->level == 'admin'): ?>
                                    <a href="/admin" class="mm-active">
                                        <i class="metismenu-icon fas fa-server"></i>
                                        Dashboard
                                    </a>
                                <?php elseif(Auth::user()->level == 'petugas'): ?>
                                    <a href="/dashboad_petugas" class="mm-active">
                                        <i class="metismenu-icon fas fa-server"></i>
                                        Dashboard
                                    </a>
                                <?php else: ?>
                                    <a href="/masyarakat" class="mm-active">
                                        <i class="metismenu-icon fas fa-server"></i>
                                        Dashboard
                                    </a>
                                <?php endif; ?>
                                </li>
                                <li class="app-sidebar__heading">Others</li>
                                <li>
                                    <a href="javascript:void(0)">
                                        <i class="metismenu-icon fas fa-database"></i>
                                        Pengaduan
                                        <i class="metismenu-state-icon fas fa-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="/pengajuan">
                                                <i class="metismenu-icon"></i>
                                                Pengajuan
                                            </a>
                                        </li>
                                        <li>
                                            <a href="/aspirasi">
                                                <i class="metismenu-icon"></i>
                                                Aspirasi
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                     
                                <li>
                                    <a href="/petugas">
                                        <i class="metismenu-icon fas fa-users"></i>
                                        Petugas
                                    </a>
                                </li>
                                <li>
                                    <a href="/masyarakat">
                                        <i class="metismenu-icon fas fa-globe-asia"></i>
                                        Masyarakat
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)">
                                        <i class="metismenu-icon fas fa-database"></i>
                                        Laporan
                                        <i class="metismenu-state-icon fas fa-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="/laporan_pengajuan">
                                                <i class="metismenu-icon"></i>
                                                Pengajuan
                                            </a>
                                        </li>
                                        <li>
                                            <a href="/laporan_aspirasi">
                                                <i class="metismenu-icon"></i>
                                                Aspirasi
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                     
                                <li class="app-sidebar__heading">App</li>
                                <li>
                                    <a href="/settings">
                                        <i class="metismenu-icon fas fa-cogs"></i>
                                        Settings
                                    </a>
                                </li>
                            
                            </ul>
                        </div>
                    </div>
                </div>    
                <?php echo $__env->yieldContent('content'); ?>
                <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        </div>
    </div>
<script type="text/javascript" src="<?php echo e(url('assets/arsitek/scripts/main.js')); ?>"></script></body>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</html>
<?php /**PATH D:\Xampp\XAMPP\htdocs\sp1\resources\views/layouts/admin.blade.php ENDPATH**/ ?>