<?php $__env->startSection('content'); ?>
<title>Profil | Layanan Pengaduan Masyarat</title>

<body>
<style>
    .card{
        border: none !important;
    }
    body{
        background-color: #f2f5f4;
    }
 .geser{
        margin-top: 50px !important;
    }
.jumbotron{
  position: relative;
}
#upload{
    display:none
}

#hapus{
    display:none
}
</style>

<!-- Jumbotron -->
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Biodata Mu  </h1>
  </div>
</div>
<!-- akhir Jumbotron -->
  <!-- ======= Mobile Menu ======= -->
  <div class="site-mobile-menu site-navbar-target">
    <div class="site-mobile-menu-header">
      <div class="site-mobile-menu-close mt-3">
        <span class="icofont-close js-menu-toggle"></span>
      </div>
    </div>
    <div class="site-mobile-menu-body"></div>
  </div>

 
<main id="main"> 
<section class="section geser">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
            <br>
                <div class="card">
                    <div class="card-header">Foto Profil</div>
                    <div class="card-body">
                        <?php if(Auth::user()->foto_profil == '0'): ?>
                            <img src="<?php echo e(url('assets/img/avatar.png')); ?>" alt="AdminLTE Logo" class="profile-user-img img-fluid img-circle">
                        <?php else: ?>
                            <img src="<?php echo e(url('/database/foto_profil/'. Auth::user()->foto_profil)); ?>" alt="" class="profile-user-img img-fluid img-circle">
                        <?php endif; ?>
                        <div class="container-fluid mt-4">
                            <div class="row">
                                <p><form action="/profil_foto_ubah" method="post" enctype="multipart/form-data" class="ml-5">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                                <input id="upload" type="file" onchange="this.form.submit()" name="foto"/>
                                <a href="" id="upload_link" class="btn btn-primary bg-gradient-primary opacity-8 text-white btn-sm">Ubah</a>​
                            </form>
                                <a href="/profil_foto_hapus/<?php echo e(Auth::user()->id); ?>" class="btn btn-danger btn-sm ml-5 delete-confirm ">Hapus</a>​</p>
                            </div>
                            <br>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mt-4">
                <div class="card">
                    <div class="card-header">Identitas</div>
                    <div class="card-body">
                        <form action="/profil_ubah_data" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                            <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nik">NIK : <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                    <input type="number" name="nik" value="<?php echo e(Auth::user()->nik); ?>" onKeyPress="if(this.value.length == 16) return false;" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nama">Nama : <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                    <input type="text" name="nama" value="<?php echo e(Auth::user()->nama); ?>" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="telp">Telp : <?php $__errorArgs = ['telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                    <input type="number" name="telp" value="<?php echo e(Auth::user()->telp); ?>" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Email : <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                    <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="username">Username : <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                    <input type="text" name="username" value="<?php echo e(Auth::user()->username); ?>" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6 mt-2"><br>
                            <button class="btn btn-primary btn-sm btn-block">Ubah</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mt-4">
                <div class="card">
                    <div class="card-header">Ganti Password</div>
                    <div class="card-body">
                        <form action="/ubah_password" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                            <div class="form-group">
                                <label for="password_lama">Password Lama  <?php $__errorArgs = ['password_lama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                <input type="password" name="password_lama" id="password_lama" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password">Password Lama <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                <input type="password" name="password" id="password" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password_confirmation">Konfirmasi Password </label>
                                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required>
                            </div>
                        <button class="btn btn-primary btn-sm btn-block">Ubah</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <br>
        
    </div>
</section>
<?php $__env->startPush('scripts'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
 
$('.delete-confirm').on('click', function (e) {
    event.preventDefault();
    const url = $(this).attr('href');
    swal({
        title: 'Apakah Anda yakin?',
        text: 'Data akan dihapus secara permanen!',
        icon: 'warning',
        buttons: ["Cancel", "Yes!"],
    }).then(function(value) {
        if (value) {
            window.location.href = url;
        }
    });
});
$(document).ready(function() {
    $('#example').DataTable();
} );
$(function(){
    $("#upload_link").on('click', function(e){
        e.preventDefault();
        $("#upload:hidden").trigger('click');
    });
});

$(function(){
    $("#hapus_link").on('click', function(e){
        e.preventDefault();
        $("#hapus:hidden").trigger('click');
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\pengajuan_masyarakat\resources\views/lapor/profil.blade.php ENDPATH**/ ?>