<?php $__env->startSection('content'); ?>
<body>
<style>
    .card{
        border: none !important;
    }
    body{
        background-color: #f2f5f4;
    }
 .geser{
        margin-top: 50px !important;
    }
</style>
  <!-- ======= Mobile Menu ======= -->
  <div class="site-mobile-menu site-navbar-target">
    <div class="site-mobile-menu-header">
      <div class="site-mobile-menu-close mt-3">
        <span class="icofont-close js-menu-toggle"></span>
      </div>
    </div>
    <div class="site-mobile-menu-body"></div>
  </div>

 
  <main id="main">

    <section class="hero-section inner-page">
      <div class="wave">

        <svg width="1920px" height="265px" viewBox="0 0 1920 265" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
          <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="Apple-TV" transform="translate(0.000000, -402.000000)" fill="#FFFFFF">
              <path d="M0,439.134243 C175.04074,464.89273 327.944386,477.771974 458.710937,477.771974 C654.860765,477.771974 870.645295,442.632362 1205.9828,410.192501 C1429.54114,388.565926 1667.54687,411.092417 1920,477.771974 L1920,667 L1017.15166,667 L0,667 L0,439.134243 Z" id="Path"></path>
            </g>
          </g>
        </svg>

      </div>

      <div class="container">
        <div class="row align-items-center">
          <div class="col-12">
            <div class="row justify-content-center">
              <div class="col-md-7 text-center hero-text">
                <h1 data-aos="fade-up" data-aos-delay="">Data Laporan</h1>
                <p class="mb-5" data-aos="fade-up" data-aos-delay="100">Kumpulan data yang Anda ajukan</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>

 

<section class="section geser">
    <div class="container">
        <div class="row\">
           <div class="card">
                <div class="card-body shadow">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link" id="pengaduan-tab" data-toggle="tab" href="#pengaduan" role="tab" aria-controls="pengaduan" aria-selected="true">Pengaduan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="tanggapan-tab" data-toggle="tab" href="#tanggapan" role="tab" aria-controls="tanggapan" aria-selected="false">Tanggapan</a>
                    </li>
                    </ul>

        <div class="tab-content">
          <div class="tab-pane active" id="pengaduan" role="tabpanel" aria-labelledby="pengaduan-tab">
            <div class="card-body">
              <br>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <table class="table ">
                <thead class="">
                  <tr class="">
                    <td><b>Tanggal<span style="margin-left: 50px">:</span></b> <span style="margin-left: 50px"><?php echo e($value->tgl_pengaduan); ?></span> </td>
                  </tr>
                  
                  <tr class="">
                    <td><b>Kode<span style="margin-left: 70px">:</span></b> <span style="margin-left: 50px"><?php echo e($value->kode_pengaduan); ?></span> </td>
                  </tr>
                  
                  <tr class="">
                    <td><b>Kategori<span style="margin-left: 45px">:</span></b> <span style="margin-left: 50px"><?php echo e($value->tgl_pengaduan); ?></span> </td>
                  </tr>
                  
                  <tr class="">
                    <td><b>Status<span style="margin-left: 59px">:</span></b> <span style="margin-left: 50px"><?php if($value->status =='0'): ?> Belum di proses <?php else: ?> <?php echo e($value->status); ?> <?php endif; ?> </span> </td>
                  </tr>
                  
                  <tr class="">
                    <td><b>Foto<span style="margin-left: 73px">:</span></b> <span style="margin-left: 50px">
                    <img src="<?php echo e(url('/database/foto_pengaduan/'.$value->foto_pengaduan)); ?>" alt="Image" class="img-fluid" style="height: 100px; width: 150px;">
                    </span> </td>
                  </tr>
                </thead>
              </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
            <div class="tab-pane" id="tanggapan" role="tabpanel" aria-labelledby="tanggapan-tab">
                <div class="card-body">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table class="table ">
                    <thead class="">
                    <?php if($value->tanggapan == '0'): ?>
                    
                        <center><b>Tidak ada tanggapan</b></center>
                    <?php else: ?>
                    <tr class="">
                        <td><b>Tanggal<span style="margin-left: 50px">:</span></b> <span style="margin-left: 50px"><?php echo e($value->tgl_tanggapan); ?></span> </td>
                    </tr>
                    
                    <tr class="">
                        <td><b>Tanggapan<span style="margin-left: 70px">:</span></b> <span style="margin-left: 50px"><?php echo e($value->tanggapan); ?></span> </td>
                    </tr>
                    <?php endif; ?>
                    </thead>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </div>
            </div>
        </div>
    </div>
</section>
<div class="container">

    
		</div>


</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\sp1\resources\views/lapor/lihat.blade.php ENDPATH**/ ?>