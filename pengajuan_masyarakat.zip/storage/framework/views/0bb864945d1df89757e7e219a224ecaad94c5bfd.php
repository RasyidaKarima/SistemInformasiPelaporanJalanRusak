<?php $__env->startSection('content'); ?>
<title>
    Detail Data Guru  | BKP Online
 </title>
<!-- Header -->
<div class="header pb-6 d-flex align-items-center" style="min-height: 300px; background-image: url(../../assets/img/brand/1.jpg); background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-primary opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid">
        <div class="col-auto">
        </div>
    </div>
</div>
    
<br>
<br>
<div class="container-fluid mt--7">

  <div class="row">
  <div class="col-xl-8 order-xl-2 offset-2">
    <div class="card shadow">
                    <div class="card-body">
                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="/guru_update">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" class="form-control" id="id_guru" name="id_guru" value="<?php echo e($p->id_guru); ?>">

                    <div class="form-group">
                      <div class="form-group">
                        <label for="nama" class="col-sm-4 control-label">Nama</label>

                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($p->nama_guru); ?>">
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="form-group">
                        <label for="username" class="col-sm-4 control-label">Username</label>

                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo e($p->username_guru); ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-group">
                        <label for="mapel" class="col-sm-4 control-label">Mapel</label>
                            <div class="col-sm-10">
                                <select name="mapel" id="mapel" class="form-control">
                                    <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($p->mapel_id == $m->id_mapel): ?>
                                        <option value="<?php echo e($m->id_mapel); ?>" selected><?php echo e($m->nama_mapel); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($m->id_mapel); ?>"><?php echo e($m->nama_mapel); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                      </div>
                    </div>


                    <div class="form-group">
                      <div class="form-group">
                        <label for="email" class="col-sm-4 control-label">Email</label>

                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="email" name="email" value="<?php echo e($p->email_guru); ?>" readonly>
                        </div>
                      </div>
                    </div>


                      <div class="form-group">
                        <div class="form-group">
                          <div class="col-sm-10">
                          <button class="btn btn-primary btn-md">Ubah</button>
                          </div>
                      </div>

                      </form>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    </div>
  </div>
</div>

</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\bkp\resources\views/pengguna/detail_guru.blade.php ENDPATH**/ ?>