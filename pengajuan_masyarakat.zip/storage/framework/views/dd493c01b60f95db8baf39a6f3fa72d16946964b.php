<?php $__env->startSection('content'); ?>

<title>
  Detail Masakan | Aplikasi Kasir Restoran
</title>
<div class="header bg-gradient-warning pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-lg-6">
            <div class="card">
            <div class="card-header">
                Ubah Data
            </div>
                <div class="card-body">
                    <form action="/masakan_update" method="POST">
                        <?php $__currentLoopData = $masakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_masakan" id="id_masakan" class="form-control" value="<?php echo e($r->id_masakan); ?>" >
                        <div class="form-group">
                            <label for="nama_masakan">Nama Masakan</label>
                            <input type="text" name="nama_masakan" id="nama_masakan" class="form-control" value="<?php echo e($r->nama_masakan); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="harga">harga</label>
                            <input type="text" name="harga" id="harga" class="form-control" value="<?php echo e($r->harga); ?>" >
                        </div>
                        <label for="kategori_id">Kategori</label>
                        <select name="kategori_id" id="kategori_id" class="form-control">
                            <?php $__currentLoopData = $masakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($m->kategori_id == $k->id_kategori): ?>
                                  <option value="<?php echo e($k->id_kategori); ?>" selected><?php echo e($k->nama_kategori); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($k->id_kategori); ?>"><?php echo e($k->nama_kategori); ?></option>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
<br>
                        <label for="status_masakan">Status Masakan</label>
                        <select name="status_masakan" id="status_masakan" class="form-control">
                        <?php if($r->status_masakan == 'tersedia'): ?>
                            <option value="tersedia" selected>Tersedia</option>
                            <?php else: ?>
                            <option value="tersedia">Tersedia</option>
                            <?php endif; ?>
                            
                            <?php if($r->status_masakan == 'kosong'): ?>
                            <option value="kosong" selected>Kosong</option>
                            <?php else: ?>
                            <option value="kosong">Kosong</option>
                            <?php endif; ?>
                        </select>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br>
                        <div class="form-group">
                            <button class="btn btn-primary btn-block">Ubah</button>
                        </div>
                    </form>
                </div>
            </div>
            </div>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\sp1\resources\views/masakan/edit.blade.php ENDPATH**/ ?>