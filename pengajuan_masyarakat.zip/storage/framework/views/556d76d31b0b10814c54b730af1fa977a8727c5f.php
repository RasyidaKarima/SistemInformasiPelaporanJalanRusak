<?php $__env->startSection('content'); ?>
<title>Lapor | Layanan Pengaduan Masyarat</title>

<body>
<style>

#idfoto_pengaduan{
   background-image:url('');
   background-size:cover;
   background-position: center;
   height: 250px; width: 250px;
   border: 1px solid #bbb;
}
.jumbotron{
  position: relative;
}
</style>

 
<!-- Jumbotron -->
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Form Pengaduan  </h1>
    <a href="javascript::void(0)" class="btn btn-primary lapor">Sampaikan pengaduan melalui form dibawah</a>
  </div>
</div>
<!-- akhir Jumbotron -->

  <!-- ======= Mobile Menu ======= -->
  <div class="site-mobile-menu site-navbar-target">
    <div class="site-mobile-menu-header">
      <div class="site-mobile-menu-close mt-3">
        <span class="icofont-close js-menu-toggle"></span>
      </div>
    </div>
    <div class="site-mobile-menu-body"></div>
  </div>

 <br><br>
  <main id="main">

    <section class="section">
      <div class="container">
        <div class="row mb-5 align-items-end">
          <div class="col-md-6" data-aos="fade-up">

            <h2>Form Pengaduan</h2>
          </div>

        </div>

        <div class="row">

        
        <div class="col-md-6 ml-auto order-2" data-aos="fade-left">
            <img src="<?php echo e(url('assets/fitur/assets/img/undraw_svg_2.svg')); ?>" alt="Image" class="img-fluid">
        </div>

          <div class="col-md-6 mb-5 mb-md-0" data-aos="fade-up">
            <form action="/lapor_store" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="row">
                
                <div class="col-md-12 form-group">
                  <label for="isi_laporan`">Isi Laporan :</label>
                  <textarea class="form-control" name="isi_laporan" cols="30" rows="10"><?php echo e(old('isi_laporan')); ?></textarea>
                  <div class="validate"></div>
                </div>

                <div class="col-md-12 form-group">
                  <label for="foto_pengaduan">Foto Pengaduan :</label>
                  <input type="file" class="form-control" name="foto_pengaduan" id="foto_pengaduan" required />
                  <!-- <div id='idfoto_pengaduan'></div> -->
                  <div class="validate"></div>
                </div>
                <?php $__errorArgs = ['foto_pengaduan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="col-sm-12">
                      <div class="col-sm-12">
                          <div class="alert bg-danger">
                              <strong class="text-white"><?php echo e($message); ?></strong>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                              </button>
                          </div>
                      </div>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   

                <div class="col-md-12 form-group">
                  <label for="kategori">Kategori : <br>
                  <input type="radio" name="kategori" id="pengajuan" value="pengajuan" <?php if(old('kategori') == 'pengajuan'): ?> checked <?php else: ?>  <?php endif; ?> required/>
                  <label for="pengajuan">Pengajuan 
                  <input type="radio" name="kategori" id="aspirasi" value="aspirasi" <?php if(old('kategori') == 'aspirasi'): ?> checked <?php else: ?> <?php endif; ?> required/> 
                  <label for="aspirasi">Aspirasi <br>
                  </label>
                  <div class="validate"></div>
                </div>
                
                <div class="col-md-12 form-group">
                  <input type="submit" class="btn btn-primary btn-block" value="Kirim">
                </div>
              </div>

            </form>
          </div>

        </div>
      </div>
    </section>
</body>

</html>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>

document.getElementById('pengaduan').addEventListener('change', readURL, true);
function readURL(){
   var file = document.getElementById("pengaduan").files[0];
   var reader = new FileReader();
   reader.onloadend = function(){
      document.getElementById('idpengaduan').style.backgroundImage = "url(" + reader.result + ")";        
   }
   if(file){
      reader.readAsDataURL(file);
    }else{
    }
}
</script>
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\pengajuan_masyarakat\resources\views/lapor/lapor.blade.php ENDPATH**/ ?>