<?php $__env->startSection('content'); ?>
<title>Laporan Pengajuan | Layanan Pengaduan Masyarakat</title>

<div class="row">
    <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        Filter Laporan Pengajuan
                    </div>
                </div>
        <div class="main-card mb-3 card">
            <div class="card-body">
                <form action="/cetak_laporan_pengajuan" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">    
                                <input type="date" class="form-control" name="dari" data-toggle='tooltip' title="Dari tanggal">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">    
                                <input type="date" class="form-control" name="ke" data-toggle='tooltip' title="Ke tanggal">
                            </div>
                        </div>
                        <div class="col-md-4">
                            
                        <div class="form-group" style="margin-top:2px;">
                            <button class="btn btn-primary">Filter</button>
                        </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <br>
        <?php if(request('dari') !=''): ?>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <tr>
                                <th></th>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        <?php else: ?>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>

$('.delete-confirm').on('click', function (e) {
    event.preventDefault();
    const url = $(this).attr('href');
    swal({
        title: 'Apakah Anda yakin?',
        text: 'Data akan dihapus secara permanen!',
        icon: 'warning',
        buttons: ["Cancel", "Yes!"],
    }).then(function(value) {
        if (value) {
            window.location.href = url;
        }
    });
});
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\colongan\pengajuan_masyarakat\resources\views/laporan/pengajuan.blade.php ENDPATH**/ ?>