<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="main-card mb-3 card">
            <div class="card-body"> 
                <div class="card-title">
                        <h5>Detail Data
                </div>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="/petugas_update" method="post">
                    <input type="hidden" name="id" value="<?php echo e($value->id); ?>">
                    <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="nama">Nama : <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                <input type="text" name="nama" value="<?php echo e($value->nama); ?>" class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="telp">telp : <?php $__errorArgs = ['telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                <input type="text" name="telp" value="<?php echo e($value->telp); ?>" class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="username">username : <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                <input type="text" name="username" value="<?php echo e($value->username); ?>" class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="email">email : <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </label>
                                <input type="text" name="email" value="<?php echo e($value->email); ?>" class="form-control">
                            </div>
                                <label for="level">Level :</label>
                            <select name="level" id="level" class="form-control">
                                <?php if($value->level == 'petugas'): ?>
                                    <option value="petugas" selected>Petugas</option>
                                <?php else: ?>
                                    <option value="petugas">Petugas</option>
                                <?php endif; ?>
                                
                                <?php if($value->level == 'admin'): ?>
                                    <option value="admin" selected>Admin</option>
                                <?php else: ?>
                                    <option value="admin">Admin</option>
                                <?php endif; ?>

                            </select>
                            <br>
                            <button class="btn btn-primary ">Update</button>
                        </div>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\pengajuan_masyarakat\resources\views/petugas/edit.blade.php ENDPATH**/ ?>