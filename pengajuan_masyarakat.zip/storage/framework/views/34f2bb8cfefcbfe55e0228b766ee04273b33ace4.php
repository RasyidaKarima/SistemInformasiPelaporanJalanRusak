<?php $__env->startSection('content'); ?>

<title>
  Tambah Masakan | Aplikasi Kasir Restoran
</title>
<div class="header bg-gradient-warning pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-lg-6">
            <div class="card">
            <div class="card-header">
                Tambah Masakan
            </div>
                <div class="card-body">
                    <form action="masakan_tambah_post" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="nama_masakan">Nama Masakan</label>
                            <input type="text" name="nama_masakan" id="nama_masakan" class="form-control" value="<?php echo e(old('nama_masakan')); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="harga">Harga</label>
                            <input type="number" name="harga" id="harga" class="form-control" value="<?php echo e(old('harga')); ?>" required>
                        </div>
                        <label for="status_masakan">Status Masakan</label>
                      <select name="status_masakan" id="status_masakan" class="form-control" required>
                      <option value="" selected disabled>Pilih Status</option>
                            <option value="tersedia">Tersedia</option>
                            <option value="kosong">Kosong</option>
                      </select>
                        <label for="kategori_id">Kategori Masakan</label>
                        <select name="kategori_id" id="kategori_id" class="form-control" required>
                        <option value="" selected disabled>Pilih Kategori</option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id_kategori); ?>"><?php echo e($k->nama_kategori); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br>
                        <button type="submit" class="btn btn-primary ">Tambah</button>
                    </form>
                </div>
            </div>
            </div>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\sp1\resources\views/masakan/tambah.blade.php ENDPATH**/ ?>