
<title>Print Laporan Aspirasi | Layanan Pengaduan Masyarakat</title>
<style>
    .hilang{
        list-style-type: none;
    }
</style>
<h1>Layanan Pengaduan Masyarakat</h1>

<h4>Laporan Pengaduan <span style="margin-left: 300px;">Tanggal : <?php echo e($dari); ?> - <?php echo e($ke); ?> <br>
<span>Kategori : Aspirasi </span>  <span style="margin-left: 305px;">Total Pengaduan : <?php echo e($pengaduan->count()); ?> </span>  </span> </h4>

<hr>
<hr>

<?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5>A. IDENTITAS</h5>
<table>
    <tr align="left">
        <th>NIK</th>
        <th>:</th>
        <th><?php echo e($value->nik); ?></th>
    </tr>
    <tr align="left">
        <th>Nama Lengkap</th>
        <th>:</th>
        <th><?php echo e($value->nama); ?></th>
    </tr>
    <tr align="left">
        <th>No. Telp</th>
        <th>:</th>
        <th><?php echo e($value->telp); ?></th>
    </tr>
</table>


<h5>B. PENGADUAN</h5>
<table>
    <tr align="left">
        <th>Kode Pengaduan</th>
        <th>:</th>
        <th><?php echo e($value->kode_pengaduan); ?></th>
    </tr>
    
    <tr align="left">
        <th>Kategori</th>
        <th>:</th>
        <th><?php echo e($value->kategori); ?></th>
    </tr>
    
    <tr align="left">
        <th>Status</th>
        <th>:</th>
        <th>
            <?php if($value->status=='0'): ?>
            Belum di proses
            <?php elseif($value->status=='proses'): ?>
            Sedang di proses
            <?php elseif($value->status=='diterima'): ?>
            Diterima
            <?php elseif($value->status=='ditolak'): ?>
            Ditolak
            <?php endif; ?>
        </th>
    </tr>
    
    <tr align="left">
        <th>Isi Pengaduan</th>
        <th>:</th>
        <th><?php echo e($value->isi_laporan); ?></th>
    </tr>

    <tr align="left">
        <th>Foto Pengaduan</th>
        <th>:</th>
        <th><img src="<?php echo e(public_path('database/foto_pengaduan/'). $value->foto_pengaduan); ?>" width="200" alt="BTS"></th>
    </tr>
    
</table>

<hr>
<hr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\pengajuan_masyarakat\resources\views/laporan/print_aspirasi.blade.php ENDPATH**/ ?>