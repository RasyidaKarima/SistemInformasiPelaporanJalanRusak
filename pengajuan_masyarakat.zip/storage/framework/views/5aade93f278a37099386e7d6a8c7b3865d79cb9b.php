<?php $__env->startSection('content'); ?>
<title>Data Pengajuan | Layanan Pengaduan Masyarakat</title>

<div class="row">
    <div class="col-lg-12">
        <div class="main-card mb-3 card">
            <div class="card-body"><h5 class="card-title">Data Pengajuan</h5><br>
                <div class="table-responsive">
                    <table class="mb-0 table" id="example">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Kode Pengaduan</th>
                            <th>Tanggal</th>
                            <th>Foto</th>
                            <th>tanggapan</th>
                            <th>Kategori</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $no = 0;?>
                        <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $no++ ;?>
                            <tr>
                                <td><?php echo $no?></td>
                                <td><?php echo e($value->kode_pengaduan); ?></td>
                                <td><?php echo e($value->tgl_pengaduan); ?></td>
                                <td> <img src="<?php echo e(url('/database/foto_pengaduan/'. $value->foto_pengaduan )); ?>" width="100" alt=""> </td>
                                <td>
                                    <?php if($value->tanggapan == '0'): ?>
                                        <i class="fas fa-exclamation text-danger"></i>
                                    <?php else: ?>
                                        <i class="fas fa-check text-success"></i>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($value->kategori); ?></td>
                                <td>
                                    <?php if($value->status == '0'): ?>
                                        Belum di proses
                                    <?php elseif($value->status == 'proses'): ?>
                                        Sedang di proses
                                    <?php elseif($value->status == 'diterima'): ?>
                                        Diterima
                                    <?php else: ?>
                                        Ditolak
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a title="Print" href="/pengajuan_print/<?php echo e($value->kode_pengaduan); ?>"> <i class="fas fa-print text-warning"></i> </a>
                                    <a title="Lihat" href="/pengajuan_lihat/<?php echo e($value->kode_pengaduan); ?>"> <i class="fas fa-eye"></i> </a>
                                    <a title="Edit" href="/pengajuan_edit/<?php echo e($value->kode_pengaduan); ?>"> <i class="fas fa-edit text-success"></i> </a>
                                    <a title="Hapus" href="/pengajuan_hapus/<?php echo e($value->kode_pengaduan); ?>" class="button delete-confirm"> <i class="fas fa-trash text-danger"></i> </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );

    
$('.delete-confirm').on('click', function (e) {
    event.preventDefault();
    const url = $(this).attr('href');
    swal({
        title: 'Apakah Anda yakin?',
        text: 'Data akan dihapus secara permanen!',
        icon: 'warning',
        buttons: ["Cancel", "Yes!"],
    }).then(function(value) {
        if (value) {
            window.location.href = url;
        }
    });
});
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\colongan\pengajuan_masyarakat\resources\views/pengajuan/index.blade.php ENDPATH**/ ?>