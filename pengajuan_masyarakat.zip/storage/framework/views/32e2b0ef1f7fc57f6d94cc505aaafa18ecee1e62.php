<?php $__env->startSection('content'); ?>

<title>
  Edit Kategori | Aplikasi Kasir Restoran
</title>
<div class="header bg-gradient-warning pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-lg-6">
            <div class="card">
            <div class="card-header">
                Ubah Kategori
            </div>
                <div class="card-body">
                    <form action="/kategori_update" method="POST">
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_kategori" value="<?php echo e($k->id_kategori); ?>">
                        <div class="form-group">
                            <label for="nama_kategori">Nama Kategori</label>
                            <input type="text" name="nama_kategori" id="nama_kategori" class="form-control" value="<?php echo e($k->nama_kategori); ?>" >
                        </div>
                      
                        <button type="submit" class="btn btn-primary ">Ubah</button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>
                </div>
            </div>
            </div>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\sp1\resources\views/kategori/edit.blade.php ENDPATH**/ ?>