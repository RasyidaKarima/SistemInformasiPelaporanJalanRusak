
<title>Print Pengajuan | Layanan Pengaduan Masyarakat</title>
<style>
    .hilang{
        list-style-type: none;
    }
</style>
<h1>Layanan Pengaduan Masyarakat</h1>

<h4>Laporan Pengaduan <span style="margin-left: 400px;">Tanggal : <?php echo e($pengaduan->tgl_pengaduan); ?>  </span> </h4>

<hr>
<hr>


<h5>A. IDENTITAS</h5>
<table>
    <tr align="left">
        <th>NIK</th>
        <th>:</th>
        <th><?php echo e($pengaduan->nik); ?></th>
    </tr>
    <tr align="left">
        <th>Nama Lengkap</th>
        <th>:</th>
        <th><?php echo e($pengaduan->nama); ?></th>
    </tr>
    <tr align="left">
        <th>No. Telp</th>
        <th>:</th>
        <th><?php echo e($pengaduan->telp); ?></th>
    </tr>
</table>


<h5>B. PENGADUAN</h5>
<table>
    <tr align="left">
        <th>Kode Pengaduan</th>
        <th>:</th>
        <th><?php echo e($pengaduan->kode_pengaduan); ?></th>
    </tr>
    
    <tr align="left">
        <th>Kategori</th>
        <th>:</th>
        <th><?php echo e($pengaduan->kategori); ?></th>
    </tr>
    
    <tr align="left">
        <th>Status</th>
        <th>:</th>
        <th>
            <?php if($pengaduan->status=='0'): ?>
            Belum di proses
            <?php elseif($pengaduan->status=='proses'): ?>
            Sedang di proses
            <?php elseif($pengaduan->status=='diterima'): ?>
            Diterima
            <?php elseif($pengaduan->status=='ditolak'): ?>
            Ditolak
            <?php endif; ?>
        </th>
    </tr>
    
    <tr align="left">
        <th>Isi Pengaduan</th>
        <th>:</th>
        <th><?php echo e($pengaduan->isi_laporan); ?></th>
    </tr>

    <tr align="left">
        <th>Foto Pengaduan</th>
        <th>:</th>
        <th><img src="<?php echo e(public_path('database/foto_pengaduan/'). $pengaduan->foto_pengaduan); ?>" width="200" alt="BTS"></th>
    </tr>

    <tr align="left">
        <th>Tanggapan :</th>
        <th>:</th>
        <th>
            <?php if($pengaduan->tanggapan == '0'): ?>
                Tidak ada tanggapan
            <?php else: ?>
            <?php echo e($pengaduan->tanggapan); ?>

            <?php endif; ?>
        </th>
    </tr>
    
</table>
<?php /**PATH D:\Xampp\XAMPP\htdocs\pengajuan_masyarakat\resources\views/pengajuan/print.blade.php ENDPATH**/ ?>