<?php $__env->startSection('content'); ?>
<title>
Detail Rombel | BKP Online
</title>
  <!-- Content Wrapper. Contains page content -->
  <!-- Header -->
  <div class="header bg-gradient-warning pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body mt-5">
          <!-- Card stats -->   
          <div class="row">
          <div class="col-xl-4 col-lg-6">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <p class="card-title text-uppercase mb-0 mt-2 text-bold"> Data Siswa Rombel <?php if($nama_rombel == ''): ?> <?php else: ?> <?php echo e($nama_rombel->nama_rombel); ?> <?php endif; ?> </p>
                      </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-primary text-white rounded-circle shadow">
                        <i class="fas fa-chart-pie"></i>
                      </div>
                    </div>
                  </div>
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid mt--7">
      <div class="row">
        <div class="col-xl-12 mb-5 mb-xl-0">
          <div class="card shadow">
            <div class="card-body">
            <div style="overflow-x:auto;">
            <table id="example" class="table table-striped table-bordered nowrap mt-3" style="overflow-x:auto;">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>NIS</th>
                                <th> Nama</th>
                                <th> Rombel</th>
                                <th>Rayon</th>
                                <th> Aksi </th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="data-row">
                                <td class="align-middle iteration"></td>
                                <td class="align-middle nis"><?php echo e($s->nis); ?></td>
                                <td class="align-middle name"><?php echo e($s->nama); ?></td>
                                <td class="align-middle word-break description"><?php echo e($s->nama_rombel); ?></td>
                                <td class="align-middle word-break description2"><?php echo e($s->nama_rayon); ?></td>
                                <td class="align-middle">
                                <button type="button" class="btn btn-sm btn-primary" id="edit-item" data-item-id="<?php echo e($s->id); ?>">Pindahkan</button>
                                </td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tfoot>
                        </table>
                </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>
        
      </div>
     
    </div>
  </div>
  
<!-- Attachment Modal -->
<div class="modal fade" id="edit-modal" tabindex="-1" role="dialog" aria-labelledby="edit-modal-label" aria-hidden="true">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="edit-modal-label">Pindah Rombel</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="attachment-body-content">
       
          <div class="card">
           
            <div class="card-body">
            <form id="edit-form" class="form-horizontal" method="POST" action="/pindahkan/rombel">
            <?php echo e(csrf_field()); ?>

              <!-- id -->
              <div class="form-group">
                <input type="hidden" name="modal_input_id" class="form-control" id="modal_input_id" required>
              </div>
              <!-- /id -->
              <!-- name -->
              <div class="form-group">
                <label class="col-form-label" for="modal_input_name">Nama</label>
                <input type="text" name="modal_input_name" class="form-control" id="modal_input_name" required readonly>
              </div>
              <!-- /name -->
              <label for="dari">Dari</label>
                <input type="text" class="form-control" value="<?php echo e($nama_rombel->nama_rombel); ?>" readonly>
                        <br>
                        <label for="ke">Ke</label>
                             <select name="rombelAkhir" id="rombelAkhir" class="form-control">
                                 <?php $__currentLoopData = $rombel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($r->id_rombel); ?>"><?php echo e($r->nama_rombel); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <option value="0">Belum Ada Rombel</option>
                             </select>
                        <br>
            </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-sm btn-primary">Pindahkan</button>
        </form>
        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

  <?php $__env->startPush('scripts'); ?>
  
    <script>
   $(document).ready(function() {
  /**
   * for showing edit item popup
   */

  $(document).on('click', "#edit-item", function() {
    $(this).addClass('edit-item-trigger-clicked'); //useful for identifying which trigger was clicked and consequently grab data from the correct row and not the wrong one.

    var options = {
      'backdrop': 'static'
    };
    $('#edit-modal').modal(options)
  })

  // on modal show
  $('#edit-modal').on('show.bs.modal', function() {
    var el = $(".edit-item-trigger-clicked"); // See how its usefull right here? 
    var row = el.closest(".data-row");

    // get the data
    var id = el.data('item-id');
    var name = row.children(".name").text();
    var description = row.children(".description").text();

    // fill the data in the input fields
    $("#modal_input_id").val(id);
    $("#modal_input_name").val(name);

  })

  // on modal hide
  $('#edit-modal').on('hide.bs.modal', function() {
    $('.edit-item-trigger-clicked').removeClass('edit-item-trigger-clicked')
    $("#edit-form").trigger("reset");
  })
})




$(document).ready(function() {
    var t = $('#example').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]]
    } );
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );
    </script>
    <?php $__env->stopPush(); ?>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\bkp\resources\views/admin/rombel_detail.blade.php ENDPATH**/ ?>