<?php $__env->startSection('content'); ?>

<title>Data Masyarakat | Layanan Pengaduan Masyarakat</title>
<div class="row">
    <div class="col-lg-12">
        <div class="main-card mb-3 card">
            <div class="card-body"> 
            <div class="card-title">
                    <h5>Data Masyarakat
                    
            </div>
            <br>
                <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>NK</th>
                            <th>Nama</th>
                            <th>No telepon</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Level</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $no = 0;?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $no++ ;?>

                        <tr>
                            <th scope="row"><?php echo $no;?></th>
                            <td><?php echo e($value->nik); ?></td>
                            <td><?php echo e($value->nama); ?></td>
                            <td><?php echo e($value->telp); ?></td>
                            <td><?php echo e($value->username); ?></td>
                            <td><?php echo e($value->email); ?></td>
                            <td>
                                <a href="/masyarakat_lihat/<?php echo e($value->id); ?>"><i class="fas fa-eye text-primary"></i></a>
                                <a href="/masyarakat_edit/<?php echo e($value->id); ?>"><i class="fas fa-edit text-success"></i></a>
                                <a href="/masyarakat_hapus/<?php echo e($value->id); ?>" class="button delete-confirm"><i class="fas fa-trash text-danger"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>

$('.delete-confirm').on('click', function (e) {
    event.preventDefault();
    const url = $(this).attr('href');
    swal({
        title: 'Apakah Anda yakin?',
        text: 'Data akan dihapus secara permanen!',
        icon: 'warning',
        buttons: ["Cancel", "Yes!"],
    }).then(function(value) {
        if (value) {
            window.location.href = url;
        }
    });
});
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\XAMPP\htdocs\pengajuan_masyarakat\resources\views/pengguna/index.blade.php ENDPATH**/ ?>